﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using productentity;
using Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace DALlayer
{
    public class ProductDal
    {
        static string ConStr = string.Empty;
        SqlConnection sqlcon;

        SqlCommand sqlcom;

        public ProductDal()
        {
            sqlcon = new SqlConnection();
            ConStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            sqlcom = new SqlCommand();
            sqlcon.ConnectionString = ConStr;
            sqlcom.Connection = sqlcon;
        }
       

      

        public void AddProductdal (Product newProduct)
        {
            

            try
            {
               
                sqlcom = new SqlCommand("naveenAddproduct", sqlcon);
                
                sqlcom.CommandType = CommandType.StoredProcedure;

                sqlcom.Parameters.AddWithValue("@SerialNumber", newProduct.SerialNumber);
                sqlcom.Parameters.AddWithValue("@ProductName", newProduct.ProductName);
                sqlcom.Parameters.AddWithValue("@BrandName", newProduct.BrandName);
                sqlcom.Parameters.AddWithValue("@ProductType", newProduct.ProductType);
                sqlcom.Parameters.AddWithValue("@ProductDescription", newProduct.ProductDescription);
                sqlcom.Parameters.AddWithValue("@UnitPrice", newProduct.UnitPrice);
                 sqlcon.Open();
                sqlcom.ExecuteNonQuery();
               
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
