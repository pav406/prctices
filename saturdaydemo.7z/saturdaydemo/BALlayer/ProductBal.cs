﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using productentity;
using Exceptions;
using DALlayer;

namespace BALlayer
{
    public class ProductBal
    {
        


        public void AddProductBal (Product product)
        {
      
            try
            {
                ProductDal productDal = new ProductDal();
                productDal.AddProductdal(product);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
