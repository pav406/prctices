﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception
{

    [Serializable]
    public class ProductException : System.Exception
    {
        public ProductException() { }
        public ProductException(string message) : base(message) { }
        public ProductException(string message, System.Exception inner) : base(message, inner) { }
        protected ProductException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
